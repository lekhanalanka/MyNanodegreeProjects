package com.example.lankalekhana.moviesstage1;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder>
{
    Context context;
    ArrayList<MovieModelClass> movieModelList;

    public MovieAdapter(MainActivity mainActivity, ArrayList<MovieModelClass> movieModelClassArrayList)
    {
        this.context=mainActivity;
        this.movieModelList=movieModelClassArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        View view = LayoutInflater.from(context).inflate(R.layout.items,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i)
    {
        Picasso.with(context).load(movieModelList.get(i).getPosterPath()).into(viewHolder.imageView);
    }

    @Override
    public int getItemCount() {
        return movieModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);

            imageView = itemView.findViewById(R.id.imgId);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int position = getAdapterPosition();

                    if(position!=-1)
                    {
                        Intent intent = new Intent(context,Main2Activity.class);
                        intent.putExtra("position",position);

                        intent.putExtra("title",movieModelList.get(position).getTitle());
                        intent.putExtra("id",movieModelList.get(position).getId());
                        intent.putExtra("release",movieModelList.get(position).getRelease());
                        intent.putExtra("popular",movieModelList.get(position).getPopularity());
                        intent.putExtra("overview",movieModelList.get(position).getOverView());
                        intent.putExtra("avg",movieModelList.get(position).getVote_average());
                        intent.putExtra("count",movieModelList.get(position).getVote_count());
                        intent.putExtra("posterPath",movieModelList.get(position).getPosterPath());

                        context.startActivity(intent);
                    }
                }
            });
        }
    }
}
