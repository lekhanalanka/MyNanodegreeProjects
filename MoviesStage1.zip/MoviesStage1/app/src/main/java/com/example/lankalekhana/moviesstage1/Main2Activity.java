package com.example.lankalekhana.moviesstage1;

import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Main2Activity extends AppCompatActivity {

    TextView avg, count, popular, release, id, title, overview;
    ImageView img;
    String imageId, title_text, release_date, vote_avg, popularity, count_vote, movieId, over_View;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        avg = findViewById(R.id.vote_average);
        count = findViewById(R.id.vote_count);
        id = findViewById(R.id.id);
        title = findViewById(R.id.title_tv);
        popular = findViewById(R.id.popularity);
        release = findViewById(R.id.release);
        overview = findViewById(R.id.overview);
        img = findViewById(R.id.image_v);

        imageId = getIntent().getStringExtra("posterPath");
        title_text = getIntent().getStringExtra("title");
        release_date = getIntent().getStringExtra("release");
        vote_avg = getIntent().getStringExtra("avg");
        popularity = getIntent().getStringExtra("popular");
        count_vote = getIntent().getStringExtra("count");
        movieId = getIntent().getStringExtra("id");
        over_View = getIntent().getStringExtra("overview");

        title.setText(title_text);
        release.setText(release_date);
        popular.setText(popularity);
        avg.setText(vote_avg);
        id.setText(movieId);
        count.setText(count_vote);
        overview.setText(over_View);
        Picasso.with(this).load(imageId).into(img);

        }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home) {

           finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
