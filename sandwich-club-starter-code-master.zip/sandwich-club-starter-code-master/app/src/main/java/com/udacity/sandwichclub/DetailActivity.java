package com.udacity.sandwichclub;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "extra_position";
    private static final int DEFAULT_POSITION = -1;

    TextView name_tv,alsoKnownas_tv, ingredient_tv, placeOfOrigin_tv, descript_tv;
    StringBuilder builder = new StringBuilder();
    StringBuilder builder1 = new StringBuilder();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView ingredientsIv = findViewById(R.id.image_iv);
        name_tv=findViewById(R.id.name_tv);
        alsoKnownas_tv=findViewById(R.id.also_known_tv);
        ingredient_tv=findViewById(R.id.ingredients_tv);
        placeOfOrigin_tv=findViewById(R.id.origin_tv);
        descript_tv=findViewById(R.id.description_tv);

        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        int position = intent.getIntExtra(EXTRA_POSITION, DEFAULT_POSITION);
        if (position == DEFAULT_POSITION) {

            closeOnError();
            return;
        }

        String[] sandwiches = getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
        Sandwich sandwich = JsonUtils.parseSandwichJson(json);
        if (sandwich == null) {

            closeOnError();
            return;
        }

        populateUI(sandwich);
        Picasso.with(this)
                .load(sandwich.getImage())
                .placeholder(R.mipmap.noimagepic)
                .into(ingredientsIv);

        setTitle(sandwich.getMainName());
    }

    private void closeOnError() {
        finish();

    }

    private void populateUI(Sandwich sandwich)
    {

            for (String also: sandwich.getAlsoKnownAs())
            {
                builder.append(also + " ");
            }

            alsoKnownas_tv.setText(builder);
            placeOfOrigin_tv.setText(sandwich.getPlaceOfOrigin());
            for (String ingredients: sandwich.getIngredients())
            {
                builder1.append(ingredients + "\n");
            }

            ingredient_tv.setText(builder1);
            descript_tv.setText(sandwich.getDescription());
            name_tv.setText(sandwich.getMainName());
    }

}
