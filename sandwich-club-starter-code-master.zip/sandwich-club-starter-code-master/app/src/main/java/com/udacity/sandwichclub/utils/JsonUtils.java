package com.udacity.sandwichclub.utils;


import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {



    public static Sandwich parseSandwichJson(String json) {

        Sandwich sandwich = new Sandwich();
        List<String> alsoKnownAsList = new ArrayList<>();
        List<String> ingredientsList = new ArrayList<>();

        try
        {
            JSONObject object = new JSONObject(json);
            JSONObject name = object.getJSONObject("name");
            String main =name.getString("mainName");
            sandwich.setMainName(main);

            JSONArray alsoKnownArray =name.getJSONArray("alsoKnownAs");

            for(int i=0;i<alsoKnownArray.length();i++)
            {
                String alsoKnownas = alsoKnownArray.getString(i);
                alsoKnownAsList.add(alsoKnownas);
            }

            sandwich.setAlsoKnownAs(alsoKnownAsList);

            String placeOfOrigin = object.getString("placeOfOrigin");
            sandwich.setPlaceOfOrigin(placeOfOrigin);

            String description = object.getString("description");
            sandwich.setDescription(description);

            String image = object.getString("image");
            sandwich.setImage(image);

            JSONArray ingred = object.getJSONArray("ingredients");
            for(int i=0;i<ingred.length();i++)
            {
                String ingredients = ingred.getString(i);
                ingredientsList.add(ingredients);
            }

            sandwich.setIngredients(ingredientsList);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return sandwich;
    }

}
