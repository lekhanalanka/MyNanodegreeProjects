package com.udacity.gradle.builditbigger;


import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import static org.junit.Assert.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.ExecutionException;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class Backend_test {

    Context backend_context;
    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void backend_test() {

        String stringVariable;
        backend_context= InstrumentationRegistry.getTargetContext();
        try{
            stringVariable=new EndpointsAsyncTask(new EndpointsAsyncTask.callback() {
                @Override
                public void myJokesData(String a) {

                }
            }).execute().get();
            assertNotNull(stringVariable);
            //assertNull(stringVariable);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }


    }

}
