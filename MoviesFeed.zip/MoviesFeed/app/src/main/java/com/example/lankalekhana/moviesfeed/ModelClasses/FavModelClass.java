package com.example.lankalekhana.moviesfeed.ModelClasses;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;
import com.example.lankalekhana.moviesfeed.Repository;

import java.util.List;

public class FavModelClass extends AndroidViewModel
{
    private Repository mRepository;
    private LiveData<List<FavouriteClass>> mFavmovies;

    public FavModelClass(@NonNull Application application) {
        super(application);

        mRepository = new Repository(application);
        mFavmovies = mRepository.getmFavmovies();
    }

    public LiveData<List<FavouriteClass>> getmFavmovies() {
        return mFavmovies;
    }
    public void insert(FavouriteClass fav_movies)
    {
        mRepository.insert(fav_movies);
    }

    public void delete(FavouriteClass fav_movies)
    {
        mRepository.delete(fav_movies);
    }

    public FavouriteClass searchForMovie(String id)
    {
        FavouriteClass model=mRepository.checkMovie(id);
        return model;
    }
}
