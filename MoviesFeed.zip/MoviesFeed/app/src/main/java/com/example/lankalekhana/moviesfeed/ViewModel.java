package com.example.lankalekhana.moviesfeed;

import android.arch.lifecycle.MutableLiveData;

import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;

import java.util.List;

public class ViewModel extends android.arch.lifecycle.ViewModel {

    MutableLiveData<List<FavouriteClass>> mutableLiveData;

    public MutableLiveData<List<FavouriteClass>> getMutableLiveData() {
        if (mutableLiveData==null){

            mutableLiveData=new MutableLiveData<>();
        }
        return mutableLiveData;
    }

    public void setList(List<FavouriteClass> list) {
        mutableLiveData.setValue(list);
    }
}
