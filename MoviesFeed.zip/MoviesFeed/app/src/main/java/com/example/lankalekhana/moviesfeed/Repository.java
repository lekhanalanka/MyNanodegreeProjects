package com.example.lankalekhana.moviesfeed;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;
import com.example.lankalekhana.moviesfeed.DAO.DataAccessObject;
import com.example.lankalekhana.moviesfeed.DAO.DataBase;

import java.util.List;

public class Repository
{
    private DataAccessObject mDataDao;
    private LiveData<List<FavouriteClass>> listLiveData;

    public Repository(Application application)
    {
        DataBase db = DataBase.getDataBase(application);
        mDataDao=db.MyData();
        listLiveData=mDataDao.getData();

    }

    public LiveData<List<FavouriteClass>> getmFavmovies() {
        return listLiveData;
    }

    public void insert(FavouriteClass fav_movies)
    {
        new insertAsyncTask(mDataDao).execute(fav_movies);
    }



    private  class insertAsyncTask extends AsyncTask<FavouriteClass,Void,Void> {

        DataAccessObject mAsyncDao;
        public insertAsyncTask(DataAccessObject mDataDao)
        {
            mAsyncDao=mDataDao;

        }

        @Override
        protected Void doInBackground(FavouriteClass... favouriteClasses) {
            mAsyncDao.insert(favouriteClasses[0]);
            return null;
        }
    }

    public void delete(FavouriteClass fav_movies)
    {
        new deleteAsyncTask(mDataDao).execute(fav_movies);
    }
    private class deleteAsyncTask extends AsyncTask<FavouriteClass,Void,Void> {

        DataAccessObject mAsyncDao1;

        public deleteAsyncTask(DataAccessObject mDataDao) {
            mAsyncDao1=mDataDao;
        }

        @Override
        protected Void doInBackground(FavouriteClass... favouriteClasses) {
            mAsyncDao1.delete(favouriteClasses[0]);
            return null;
        }
    }

    public FavouriteClass checkMovie(String id)
    {
        FavouriteClass model=mDataDao.checkFavoriteMovie(id);
        return model;
    }
}
