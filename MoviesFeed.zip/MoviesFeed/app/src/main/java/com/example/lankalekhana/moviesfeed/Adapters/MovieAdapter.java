package com.example.lankalekhana.moviesfeed.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.lankalekhana.moviesfeed.DetailsActivity;
import com.example.lankalekhana.moviesfeed.MainActivity;
import com.example.lankalekhana.moviesfeed.ModelClasses.MoviesModelClass;
import com.example.lankalekhana.moviesfeed.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieHolder>
{
    Context context;
    ArrayList<MoviesModelClass> movieModelList;

    public MovieAdapter(MainActivity mainActivity, ArrayList<MoviesModelClass> moviesModelClassArrayList)
    {
        this.context = mainActivity;
        this.movieModelList = moviesModelClassArrayList;
    }

    @NonNull
    @Override
    public MovieHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.items,viewGroup,false);
        return new MovieHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieHolder movieHolder, int i) {

        Picasso.with(context).load(movieModelList.get(i).getPoster()).into(movieHolder.imageView);
        }

    @Override
    public int getItemCount() {
        return movieModelList.size();
    }

    public class MovieHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public MovieHolder(@NonNull View itemView) {
            super(itemView);

            imageView = (itemView).findViewById(R.id.imgId);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int position = getAdapterPosition();

                    if(position!=-1)
                    {
                        Intent intent = new Intent(context,DetailsActivity.class);
                        intent.putExtra("position",position);
                        intent.putExtra("title",movieModelList.get(position).getTitle());
                        intent.putExtra("release",movieModelList.get(position).getRelease_date());
                        intent.putExtra("overview",movieModelList.get(position).getOverview());
                        intent.putExtra("avg",movieModelList.get(position).getVote_avg());
                        intent.putExtra("posterPath",movieModelList.get(position).getPoster());
                        intent.putExtra("id",movieModelList.get(position).getId());

                        context.startActivity(intent);
                    }
                }
            });
        }
    }
}
