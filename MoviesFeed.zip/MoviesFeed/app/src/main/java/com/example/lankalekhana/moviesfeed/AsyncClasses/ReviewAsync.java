package com.example.lankalekhana.moviesfeed.AsyncClasses;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.lankalekhana.moviesfeed.Adapters.ReviewAdapter;
import com.example.lankalekhana.moviesfeed.DetailsActivity;
import com.example.lankalekhana.moviesfeed.ModelClasses.ReviewModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ReviewAsync extends AsyncTask<String,Void,String> {

    ArrayList<ReviewModel> reviewModelArrayList;
    Context context;
    RecyclerView review_recycler;

    public ReviewAsync(DetailsActivity detailsActivity, ArrayList<ReviewModel> rev, RecyclerView recyc_review) {

        this.context = detailsActivity;
        this.reviewModelArrayList = rev;
        this.review_recycler = recyc_review;
    }


    @Override
    protected String doInBackground(String... strings) {

        String id =strings[0];
        URL url1 = null;
        String url="https://api.themoviedb.org/3/movie/"+id+"/reviews?api_key=a94040b9f54a45b33a89e8978c354b86";
        try {
            url1 = new URL(url);

            HttpURLConnection httpURLConnection= (HttpURLConnection) url1.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();
            InputStream inputStream=httpURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder=new StringBuilder();
            String line="";
            while ((line=bufferedReader.readLine())!=null){

                stringBuilder.append(line);
            }
            return stringBuilder.toString();

        } catch (Exception e) {
            e.printStackTrace();
    }

        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

      //  Toast.makeText(context, ""+s, Toast.LENGTH_SHORT).show();

        reviewModelArrayList= new ArrayList<>();
        try {

            JSONObject root = new JSONObject(s);
            JSONArray results = root.getJSONArray("results");
            for (int i=0;i<results.length();i++)
            {
                JSONObject object = results.getJSONObject(i);
                String author = object.getString("author");
                String content = object.getString("content");

                ReviewModel reviewModelClass = new ReviewModel(author,content);
                reviewModelArrayList.add(reviewModelClass);
            }

            if(reviewModelArrayList.size()==0)
            {
                Toast.makeText(context, "No Reviews", Toast.LENGTH_SHORT).show();
            }
            ReviewAdapter reviewAdapter = new ReviewAdapter(context,reviewModelArrayList);
            review_recycler.setAdapter(reviewAdapter);
            review_recycler.setLayoutManager(new LinearLayoutManager(context));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
