package com.example.lankalekhana.moviesfeed;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.lankalekhana.moviesfeed.Adapters.FavouriteAdapter;
import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;
import com.example.lankalekhana.moviesfeed.DAO.DataBase;
import com.example.lankalekhana.moviesfeed.ModelClasses.FavModelClass;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    GridLayoutManager gridLayoutManager;
    AsyncTaskClass asyncTaskClass;
    DataBase database;
    ViewModel viewModel;
    List<FavouriteClass> arrayList;
    public static final String POP = "popular";
    public static final String TOP = "top_rated";
    public static final String FAVOURITE = "favourite";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    FavModelClass favouriteModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        favouriteModel = ViewModelProviders.of(this).get(FavModelClass.class);


        sharedPreferences = getSharedPreferences("movies", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        viewModel=ViewModelProviders.of(this).get(com.example.lankalekhana.moviesfeed.ViewModel.class);

        database = Room.databaseBuilder(this, DataBase.class, "movies.db").allowMainThreadQueries().build();
        checkInternet(POP);
        arrayList = new ArrayList<>();

        if (getApplicationContext().getResources().getConfiguration().orientation ==
                Configuration.ORIENTATION_PORTRAIT) {
            gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
            recyclerView.setLayoutManager(gridLayoutManager);
        } else {
            gridLayoutManager = new GridLayoutManager(MainActivity.this, 4);
            recyclerView.setLayoutManager(gridLayoutManager);
        }


        String key = sharedPreferences.getString("key", null);
        if (key != null) {
            if (key.equalsIgnoreCase(POP)) {
                checkInternet(POP);
            } else if (key.equalsIgnoreCase(TOP)) {
                checkInternet(TOP);
            }
            else
                displayData();
        }

        else {
            checkInternet(POP);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (item.isChecked()){
            item.setChecked(false);
        return true;
    }
        else {
            item.setChecked(true);
            }

        switch (id) {

            case R.id.action_popular:
                checkInternet(POP);
                editor.putString("key", POP);
                editor.apply();
                break;

            case R.id.action_topRated:
                checkInternet(TOP);
                editor.putString("key", TOP);
                editor.apply();
                break;

            case R.id.action_Favourite:
                editor.putString("key", FAVOURITE);
                editor.apply();
                displayData();
                break;
           default:
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    private void displayData() {

      database = Room.databaseBuilder(this, DataBase.class, "movies.db").allowMainThreadQueries().build();


        favouriteModel.getmFavmovies().observe(this, new Observer<List<FavouriteClass>>() {
            @Override
            public void onChanged(@Nullable List<FavouriteClass> fav_movies) {
                arrayList = fav_movies;
                FavouriteAdapter adapter = new FavouriteAdapter(MainActivity.this, arrayList);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                if (getApplicationContext().getResources().getConfiguration().orientation ==
                        Configuration.ORIENTATION_PORTRAIT) {
                    gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
                    recyclerView.setLayoutManager(gridLayoutManager);
                } else {
                    gridLayoutManager = new GridLayoutManager(MainActivity.this, 4);
                    recyclerView.setLayoutManager(gridLayoutManager);
                }
            }
        });

    }

    public void checkInternet(String mtype) {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            asyncTaskClass = new AsyncTaskClass(this);
            asyncTaskClass.execute(mtype);
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Error");
            builder.setMessage("\n No Internet Connection...");
            builder.setCancelable(false);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.show();
        }


    }

}
