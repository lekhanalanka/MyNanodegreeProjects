package com.example.lankalekhana.moviesfeed;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.widget.GridLayoutManager;

import com.example.lankalekhana.moviesfeed.Adapters.MovieAdapter;
import com.example.lankalekhana.moviesfeed.ModelClasses.MoviesModelClass;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class AsyncTaskClass extends AsyncTask<String,Void,String>
{
    MainActivity mainActivity;
    String img_link = "https://image.tmdb.org/t/p/w500";
    ArrayList<MoviesModelClass> moviesModelClassArrayList ;
    ProgressDialog progressDialog;

    public AsyncTaskClass(MainActivity mainActivity) {

        this.mainActivity=mainActivity;
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();

        progressDialog = new ProgressDialog(mainActivity);
        progressDialog.setTitle("Please Wait");
        progressDialog.setMessage("Loading...");
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... strings)
    {

        String movie_type = strings[0];
        String url = "https://api.themoviedb.org/3/movie/"+movie_type+"?api_key=a94040b9f54a45b33a89e8978c354b86";

        try {
            URL url1 = new URL(url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url1.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder = new StringBuilder();
            String s = " ";
            while((s=bufferedReader.readLine())!=null)
            {
                stringBuilder.append(s);
            }

            return stringBuilder.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(String s)
    {
        super.onPostExecute(s);

        moviesModelClassArrayList = new ArrayList<>();

        try {
            JSONObject root = new JSONObject(s);
            JSONArray results = root.getJSONArray("results");

            for(int i=0;i<results.length();i++)
            {
                JSONObject jsonObject = results.getJSONObject(i);
                String vote_avg = jsonObject.getString("vote_average");
                String title = jsonObject.getString("title");
                String release_date = jsonObject.getString("release_date");
                String overview = jsonObject.getString("overview");
                String poster = img_link + jsonObject.getString("poster_path");
                String id =jsonObject.getString("id");

                MoviesModelClass movieModelClass = new MoviesModelClass(id,poster,title,release_date,vote_avg,overview);
                moviesModelClassArrayList.add(movieModelClass);

            }

            MovieAdapter movieAdapter = new MovieAdapter(mainActivity,moviesModelClassArrayList);
            mainActivity.recyclerView.setAdapter(movieAdapter);
            movieAdapter.notifyDataSetChanged();
            progressDialog.dismiss();

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}
