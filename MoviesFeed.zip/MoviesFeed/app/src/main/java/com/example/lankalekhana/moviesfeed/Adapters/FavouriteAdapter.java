package com.example.lankalekhana.moviesfeed.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;
import com.example.lankalekhana.moviesfeed.DetailsActivity;
import com.example.lankalekhana.moviesfeed.MainActivity;
import com.example.lankalekhana.moviesfeed.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class FavouriteAdapter extends RecyclerView.Adapter<FavouriteAdapter.FavouriteHolder> {

    List<FavouriteClass> arrayList;
    Context context;

    public FavouriteAdapter(MainActivity mainActivity, List<FavouriteClass> arrayList) {

        this.arrayList=arrayList;
        this.context=mainActivity;
    }

    @NonNull
    @Override
    public FavouriteHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new FavouriteHolder(LayoutInflater.from(context).inflate(R.layout.items,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull FavouriteHolder favouriteHolder, int i) {

        Picasso.with(context).load(arrayList.get(i).getPoster_path()).into(favouriteHolder.imageView);

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class FavouriteHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public FavouriteHolder(@NonNull View itemView) {
            super(itemView);

            imageView=itemView.findViewById(R.id.imgId);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    if (position!=RecyclerView.NO_POSITION){
                        Intent intent=new Intent(context,DetailsActivity.class);
                        intent.putExtra("posterPath",arrayList.get(position).getPoster_path());
                        intent.putExtra("title", arrayList.get(position).getMov_name());
                        intent.putExtra("id", String.valueOf(arrayList.get(position).getId()));
                        intent.putExtra("release", arrayList.get(position).getRelease_date());
                        intent.putExtra("overview",arrayList.get(position).getOverView());
                        intent.putExtra("avg", arrayList.get(position).getVote_avg());
                        context.startActivity(intent);

                    }
                }
            });

        }
    }
}
